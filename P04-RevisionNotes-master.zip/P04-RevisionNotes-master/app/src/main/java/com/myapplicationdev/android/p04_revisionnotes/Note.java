package com.myapplicationdev.android.p04_revisionnotes;

public class Note {
    private int id;
    private String content;
    private Integer stars;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Integer getStars() {
        return stars;
    }

    public void setStars(Integer stars) {
        this.stars = stars;
    }

    public Note(int id, String content, Integer stars) {
        this.id = id;
        this.content = content;
        this.stars = stars;
    }
}
